# Dataset instructions

Place your own appropriately licensed `grocery_prices.csv` in this folder.

Required columns: `date,country,product,price,currency,unit`

Use a trustworthy source such as a national statistics agency, and retain source URLs and collection dates in your project notes. Do not treat example values in the main README as verified prices.
