# Global Grocery Store Inflation Analysis (Sample Project)

A sample Python data-analysis project exploring how grocery prices change over time and vary by product or market. It demonstrates a reproducible workflow for loading data, cleaning records, summarising price movements, and producing charts.

> **Important:** This is a starter portfolio project created from scratch. It does not include verified real-world findings or claim that any particular country experienced a specific inflation rate. Results depend on the dataset you supply.

## Project structure

```text
grocery-inflation-analysis/
├── data/
│   └── README.md
├── reports/
├── src/
│   └── analyze_inflation.py
├── requirements.txt
└── .gitignore
```

## Dataset

Place a CSV file at `data/grocery_prices.csv`. It should contain these columns:

- `date` — date of observation, e.g. `2024-01-01`
- `country` — country or market name
- `product` — grocery product name
- `price` — numeric price
- `currency` — currency code, e.g. `EUR`, `USD`, `INR`
- `unit` — comparable unit, e.g. `1 kg`, `1 litre`, `12 eggs`

Example CSV structure:

```csv
date,country,product,price,currency,unit
2024-01-01,Ireland,Milk,1.35,EUR,1 litre
2024-02-01,Ireland,Milk,1.38,EUR,1 litre
2024-01-01,Ireland,Rice,2.10,EUR,1 kg
```

The sample values above are illustrative only, not verified market prices. Replace them with sourced data before drawing conclusions. Try to keep products, pack sizes, units, and retailers consistent over time.

## Run the analysis

Use Python 3.10+.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
python src/analyze_inflation.py --input data/grocery_prices.csv --output-dir reports
```

The script creates:
- `cleaned_grocery_prices.csv`
- `monthly_price_trends.png`
- `price_change_summary.csv`

It reports price change for each country/product/unit series from its first to last available observation. This is **not the same as an official consumer price index (CPI)**.

## Analysis approach

1. Parse dates and numeric prices.
2. Remove invalid records and non-positive prices.
3. Group by country, product, currency, and unit.
4. Sort each series chronologically.
5. Compare first and last recorded prices.
6. Plot monthly mean prices for selected series.

## Responsible interpretation

- Price comparisons are only meaningful when product definitions, pack sizes, units, and currency are comparable.
- The first-to-last change depends on the chosen observation period and is not an official inflation measure.
- Document the dataset source, collection date, licences, and limitations.
- Do not describe illustrative sample values as real market data.

## Suggested improvements

- Add data from official national statistics agencies.
- Calculate year-over-year change using matched months.
- Compare product categories and countries with clear unit/currency handling.
- Add missing-data checks and outlier review.
- Build an interactive dashboard in Tableau or Power BI.
